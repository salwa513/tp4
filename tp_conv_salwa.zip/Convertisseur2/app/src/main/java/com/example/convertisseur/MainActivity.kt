package com.example.convertisseur

import android.os.Bundle
import android.widget.ArrayAdapter
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import com.example.convertisseur.databinding.ActivityMainBinding

class MainActivity : AppCompatActivity() {

    private lateinit var binding: ActivityMainBinding

    // Taux exprimés pour 1 EUR
    private val taux = mapOf(
        "EUR" to 1.0,
        "USD" to 1.17,
        "TND" to 3.40,
        "GBP" to 0.87,
        "JPY" to 172.50,
        "CAD" to 1.62
    )

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        // Initialisation du View Binding
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)

        configurerSpinners()
        configurerClavier()
        configurerBoutonConvertir()
        configurerBoutonEffacer()
        configurerBoutonInverser()
    }

    // =====================================================
    // SPINNERS
    // =====================================================

    private fun configurerSpinners() {

        val adapter = ArrayAdapter.createFromResource(
            this,
            R.array.devises,
            android.R.layout.simple_spinner_item
        )

        adapter.setDropDownViewResource(
            android.R.layout.simple_spinner_dropdown_item
        )

        binding.spDeviseSource.adapter = adapter
        binding.spDeviseCible.adapter = adapter

        // Par défaut : USD -> EUR
        binding.spDeviseSource.setSelection(0)
        binding.spDeviseCible.setSelection(1)
    }

    // =====================================================
    // CLAVIER NUMÉRIQUE
    // =====================================================

    private fun configurerClavier() {

        binding.btn0.setOnClickListener {
            ajouterCaractere("0")
        }

        binding.btn1.setOnClickListener {
            ajouterCaractere("1")
        }

        binding.btn2.setOnClickListener {
            ajouterCaractere("2")
        }

        binding.btn3.setOnClickListener {
            ajouterCaractere("3")
        }

        binding.btn4.setOnClickListener {
            ajouterCaractere("4")
        }

        binding.btn5.setOnClickListener {
            ajouterCaractere("5")
        }

        binding.btn6.setOnClickListener {
            ajouterCaractere("6")
        }

        binding.btn7.setOnClickListener {
            ajouterCaractere("7")
        }

        binding.btn8.setOnClickListener {
            ajouterCaractere("8")
        }

        binding.btn9.setOnClickListener {
            ajouterCaractere("9")
        }

        binding.btnVirgule.setOnClickListener {
            ajouterCaractere(".")
        }
    }

    // =====================================================
    // AJOUTER UN CARACTÈRE
    // =====================================================

    private fun ajouterCaractere(caractere: String) {

        var montant = binding.tvMontant.text.toString()

        // Le premier chiffre remplace le 0 initial
        if (montant == "0") {
            montant = caractere
        } else {

            // Un deuxième point est interdit
            if (caractere == "." && montant.contains(".")) {
                return
            }

            montant += caractere
        }

        // Maximum 10 caractères
        if (montant.length <= 10) {
            binding.tvMontant.text = montant
        }
    }

    // =====================================================
    // BOUTON C
    // =====================================================

    private fun configurerBoutonEffacer() {

        binding.btnC.setOnClickListener {

            binding.tvMontant.text = "0"
            binding.tvResultat.text = ""
        }
    }

    // =====================================================
    // BOUTON CONVERTIR
    // =====================================================

    private fun configurerBoutonConvertir() {

        binding.btnConvertir.setOnClickListener {

            val montantTexte =
                binding.tvMontant.text.toString()

            // Vérifier si le montant est valide
            val montant =
                montantTexte.toDoubleOrNull()

            if (montant == null || montant == 0.0) {

                Toast.makeText(
                    this,
                    "Veuillez saisir un montant",
                    Toast.LENGTH_SHORT
                ).show()

                return@setOnClickListener
            }

            // Récupérer la devise source
            val source =
                binding.spDeviseSource.selectedItem.toString()

            // Récupérer la devise cible
            val cible =
                binding.spDeviseCible.selectedItem.toString()

            // Effectuer la conversion
            val resultat =
                convertir(montant, source, cible)

            // Afficher avec 2 décimales
            binding.tvResultat.text =
                String.format("%.2f", resultat)
        }
    }

    // =====================================================
    // FONCTION DE CONVERSION
    // =====================================================

    private fun convertir(
        montant: Double,
        source: String,
        cible: String
    ): Double {

        // Taux de la devise source par rapport à l'euro
        val tauxSource =
            taux[source] ?: 1.0

        // Taux de la devise cible par rapport à l'euro
        val tauxCible =
            taux[cible] ?: 1.0

        // Conversion source -> EUR
        val montantEnEUR =
            montant / tauxSource

        // Conversion EUR -> cible
        return montantEnEUR * tauxCible
    }

    // =====================================================
    // BOUTON INVERSER
    // =====================================================

    private fun configurerBoutonInverser() {

        binding.btnInverser.setOnClickListener {

            val positionSource =
                binding.spDeviseSource.selectedItemPosition

            val positionCible =
                binding.spDeviseCible.selectedItemPosition

            // Échanger les deux devises
            binding.spDeviseSource
                .setSelection(positionCible)

            binding.spDeviseCible
                .setSelection(positionSource)

            // Si un résultat existe, refaire la conversion
            if (binding.tvResultat.text.toString().isNotEmpty()) {

                val montant =
                    binding.tvMontant.text.toString()
                        .toDoubleOrNull()

                if (montant != null && montant != 0.0) {

                    val source =
                        binding.spDeviseSource
                            .selectedItem.toString()

                    val cible =
                        binding.spDeviseCible
                            .selectedItem.toString()

                    val resultat =
                        convertir(
                            montant,
                            source,
                            cible
                        )

                    binding.tvResultat.text =
                        String.format(
                            "%.2f",
                            resultat
                        )
                }
            }
        }
    }
}